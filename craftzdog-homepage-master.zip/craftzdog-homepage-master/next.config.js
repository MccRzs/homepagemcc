module.exports = {
  reactStrictMode: true
}
